var searchData=
[
  ['verifierformatmail_0',['verifierFormatMail',['../class_share_count.html#aa2c747501448e6bf2bf2917a42734403',1,'ShareCount']]],
  ['verifierformattelephone_1',['verifierFormatTelephone',['../class_share_count.html#a6f587946a4d536f2215408bc6c9a1280',1,'ShareCount']]]
];
