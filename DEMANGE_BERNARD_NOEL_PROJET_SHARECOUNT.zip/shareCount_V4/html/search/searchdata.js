var indexSectionsWithContent =
{
  0: "agmsuv",
  1: "gmsu",
  2: "agmsuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

