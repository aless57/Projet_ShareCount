/*#include "testsharecount.hpp"
#include <stdio.h>

int main(){
    TestShareCount tsc();
    //tsc.testVerifierFormat();

}*/
