#include "testsharecount.hpp"

/**
 * @brief constructeur de la classe
 */
TestShareCount::TestShareCount()
{}

/**
 * @brief test de la fonction verifierFormatMail
 */
void testVerifierFormatMail(){
    ShareCount sc();
    QString mail="r@gmail.com";
    //verifierFormatMail(mail);
}
