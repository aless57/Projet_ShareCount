#ifndef GESTIONNAIREDIALOGUE_H
#define GESTIONNAIREDIALOGUE_H

/**
 * @brief The GestionnaireDialogue class
 * Gère les interractions entre les utilisateurs et l'application
 */

class GestionnaireDialogue
{
public:

    /**
     * @brief le constructeur de la classe GestionnaireDialogue
     */
    GestionnaireDialogue();
};

#endif // GESTIONNAIREDIALOGUE_H
