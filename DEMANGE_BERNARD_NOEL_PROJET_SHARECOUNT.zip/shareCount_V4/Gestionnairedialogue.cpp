#include "Gestionnairedialogue.h"

/**
* @brief le constructeur de la classe GestionnaireDialogue
*/
GestionnaireDialogue::GestionnaireDialogue()
{

}
